from array import array
import math

from controller import Robot

import rclpy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image, Imu, JointState, LaserScan


TIME_STEP = 16
LOG_PERIOD_STEPS = 120
CMD_TIMEOUT_SECONDS = 0.75

LEG_PREFIXES = ("lf", "lm", "lr", "rf", "rm", "rr")
LEFT_LEGS = {"lf", "lm", "lr"}
TRIPOD_A = {"lf", "rm", "lr"}

COXA_BASE_SWING = 0.22
FEMUR_STAND = 0.40
TIBIA_STAND = 0.32
FEMUR_LIFT_DELTA = 0.16
TIBIA_LIFT_DELTA = 0.14
DEFAULT_STEP_PERIOD = 1.6

JOINT_SUFFIXES = ("coxa_joint", "femur_joint", "tibia_joint")


def clamp(value, lower, upper):
    return max(lower, min(value, upper))


def quaternion_from_rpy(roll, pitch, yaw):
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    return (
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy,
        cr * cp * cy + sr * sp * sy,
    )


class LegacyHexapodRos2Bridge:
    def __init__(self):
        self.robot = Robot()
        self.time_step = int(self.robot.getBasicTimeStep()) or TIME_STEP
        self.motors = {}
        self.position_sensors = {}
        self.joint_names = []
        self.current_linear = 0.0
        self.current_angular = 0.0
        self.last_cmd_time = 0.0

        self._init_actuators()
        self._init_webots_sensors()
        self._init_ros()

    def _device(self, name):
        device = self.robot.getDevice(name)
        if device is None:
            raise RuntimeError(f"Missing device: {name}")
        return device

    def _init_actuators(self):
        for leg in LEG_PREFIXES:
            for suffix in JOINT_SUFFIXES:
                joint_name = f"{leg}_{suffix}"
                sensor_name = f"{joint_name}_sensor"
                motor = self._device(joint_name)
                sensor = self._device(sensor_name)
                motor.setVelocity(2.0)
                sensor.enable(self.time_step)
                self.motors[joint_name] = motor
                self.position_sensors[sensor_name] = sensor
                self.joint_names.append(joint_name)

    def _init_webots_sensors(self):
        self.lidar = self._device("lidar")
        self.lidar.enable(self.time_step)

        self.depth_camera = self._device("depth_camera")
        self.depth_camera.enable(self.time_step)

        self.inertial_unit = self._device("imu")
        self.inertial_unit.enable(self.time_step)

        self.accelerometer = self._device("accelerometer")
        self.accelerometer.enable(self.time_step)

        self.gyro = self._device("gyro")
        self.gyro.enable(self.time_step)

    def _init_ros(self):
        rclpy.init(args=None)
        self.node = rclpy.create_node("legacy_hexapod_bridge")
        self.joint_state_pub = self.node.create_publisher(JointState, "/joint_states", 10)
        self.scan_pub = self.node.create_publisher(LaserScan, "/scan", 10)
        self.imu_pub = self.node.create_publisher(Imu, "/imu/data_raw", 10)
        self.depth_pub = self.node.create_publisher(Image, "/camera/depth/image_raw", 10)
        self.cmd_sub = self.node.create_subscription(Twist, "/cmd_vel", self._cmd_vel_callback, 10)

    def _cmd_vel_callback(self, msg):
        self.current_linear = clamp(msg.linear.x, -0.20, 0.20)
        self.current_angular = clamp(msg.angular.z, -1.00, 1.00)
        self.last_cmd_time = self._sim_time()

    def _sim_time(self):
        return self.robot.getTime()

    @staticmethod
    def _side_sign(leg_prefix):
        return 1.0 if leg_prefix in LEFT_LEGS else -1.0

    @staticmethod
    def _coxa_sign(leg_prefix):
        return -1.0 if leg_prefix in LEFT_LEGS else 1.0

    def _stance_targets(self, leg_prefix):
        side_sign = self._side_sign(leg_prefix)
        return (0.0, side_sign * FEMUR_STAND, -side_sign * TIBIA_STAND)

    def _leg_targets(self, leg_prefix, phase, linear_gain, angular_gain):
        tripod_phase = phase if leg_prefix in TRIPOD_A else phase + math.pi
        swing = math.sin(tripod_phase)
        lift = max(0.0, swing)

        side_sign = self._side_sign(leg_prefix)
        coxa_sign = self._coxa_sign(leg_prefix)
        turn_bias = angular_gain * (1.0 if leg_prefix in ("lf", "lm", "lr") else -1.0)

        coxa = coxa_sign * (COXA_BASE_SWING * linear_gain * swing + 0.10 * turn_bias)
        femur = side_sign * (FEMUR_STAND - FEMUR_LIFT_DELTA * linear_gain * lift)
        tibia = -side_sign * (TIBIA_STAND + TIBIA_LIFT_DELTA * linear_gain * lift)
        return coxa, femur, tibia

    def _set_leg_positions(self, leg_prefix, coxa, femur, tibia):
        self.motors[f"{leg_prefix}_coxa_joint"].setPosition(coxa)
        self.motors[f"{leg_prefix}_femur_joint"].setPosition(femur)
        self.motors[f"{leg_prefix}_tibia_joint"].setPosition(tibia)

    def _publish_joint_states(self):
        stamp = self.node.get_clock().now().to_msg()
        msg = JointState()
        msg.header.stamp = stamp
        msg.name = list(self.joint_names)
        msg.position = [self.position_sensors[f"{name}_sensor"].getValue() for name in self.joint_names]
        self.joint_state_pub.publish(msg)

    def _publish_imu(self):
        stamp = self.node.get_clock().now().to_msg()
        roll, pitch, yaw = self.inertial_unit.getRollPitchYaw()
        qx, qy, qz, qw = quaternion_from_rpy(roll, pitch, yaw)
        ax, ay, az = self.accelerometer.getValues()
        gx, gy, gz = self.gyro.getValues()

        msg = Imu()
        msg.header.stamp = stamp
        msg.header.frame_id = "imu_link"
        msg.orientation.x = qx
        msg.orientation.y = qy
        msg.orientation.z = qz
        msg.orientation.w = qw
        msg.angular_velocity.x = gx
        msg.angular_velocity.y = gy
        msg.angular_velocity.z = gz
        msg.linear_acceleration.x = ax
        msg.linear_acceleration.y = ay
        msg.linear_acceleration.z = az
        self.imu_pub.publish(msg)

    def _publish_scan(self):
        stamp = self.node.get_clock().now().to_msg()
        resolution = self.lidar.getHorizontalResolution()
        layers = self.lidar.getNumberOfLayers()
        fov = self.lidar.getFov()
        ranges = list(self.lidar.getRangeImage())
        middle_layer = layers // 2
        start = middle_layer * resolution
        end = start + resolution
        scan_ranges = ranges[start:end]

        msg = LaserScan()
        msg.header.stamp = stamp
        msg.header.frame_id = "lidar_link"
        msg.angle_min = -fov * 0.5
        msg.angle_max = fov * 0.5
        msg.angle_increment = fov / float(resolution)
        msg.range_min = self.lidar.getMinRange()
        msg.range_max = self.lidar.getMaxRange()
        msg.ranges = scan_ranges
        self.scan_pub.publish(msg)

    def _publish_depth(self):
        stamp = self.node.get_clock().now().to_msg()
        width = self.depth_camera.getWidth()
        height = self.depth_camera.getHeight()
        depth_image = list(self.depth_camera.getRangeImage())

        msg = Image()
        msg.header.stamp = stamp
        msg.header.frame_id = "depth_camera"
        msg.height = height
        msg.width = width
        msg.encoding = "32FC1"
        msg.is_bigendian = False
        msg.step = width * 4
        msg.data = array("f", depth_image).tobytes()
        self.depth_pub.publish(msg)

    def _log_snapshot(self, step_count):
        if step_count % LOG_PERIOD_STEPS != 0:
            return
        roll, pitch, yaw = self.inertial_unit.getRollPitchYaw()
        self.node.get_logger().info(
            f"sim={self._sim_time():.2f}s cmd=({self.current_linear:.2f}, {self.current_angular:.2f}) "
            f"rpy=({roll:.3f}, {pitch:.3f}, {yaw:.3f})"
        )

    def _apply_motion(self, step_count):
        now = self._sim_time()
        cmd_age = now - self.last_cmd_time
        active = cmd_age < CMD_TIMEOUT_SECONDS
        linear_gain = clamp(abs(self.current_linear) / 0.12, 0.0, 1.0) if active else 0.0
        angular_gain = clamp(self.current_angular / 0.8, -1.0, 1.0) if active else 0.0

        if linear_gain < 0.05 and abs(angular_gain) < 0.05:
            for leg_prefix in LEG_PREFIXES:
                self._set_leg_positions(leg_prefix, *self._stance_targets(leg_prefix))
            return

        activity = max(linear_gain, abs(angular_gain))
        step_period = DEFAULT_STEP_PERIOD - 0.6 * activity
        phase = 2.0 * math.pi * (step_count * self.time_step / 1000.0) / step_period

        for leg_prefix in LEG_PREFIXES:
            targets = self._leg_targets(leg_prefix, phase, max(activity, 0.3), angular_gain)
            self._set_leg_positions(leg_prefix, *targets)

    def run(self):
        step_count = 0
        while self.robot.step(self.time_step) != -1:
            rclpy.spin_once(self.node, timeout_sec=0.0)
            self._apply_motion(step_count)
            self._publish_joint_states()
            self._publish_scan()
            self._publish_imu()
            self._publish_depth()
            step_count += 1
            self._log_snapshot(step_count)

        self.node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    LegacyHexapodRos2Bridge().run()
