# Ubuntu Webots + ROS 2

This project includes a ROS 2 bridge controller for the legacy hexapod:

- `controllers/legacy_hexapod_ros2_bridge/legacy_hexapod_ros2_bridge.py`
- `worlds/legacy_hexapod_ros2_bridge_test.wbt`

## Recommended stack

- Ubuntu 22.04 with ROS 2 Humble
- Webots R2025a

## Install ROS 2 Python dependencies

```bash
sudo apt update
sudo apt install -y python3-rclpy ros-humble-sensor-msgs ros-humble-geometry-msgs
```

If `sensor_msgs` and `geometry_msgs` are already present in your ROS installation, the command above is enough.

## Run

Open a terminal, source ROS 2, and then launch Webots from the same terminal:

```bash
source /opt/ros/humble/setup.bash
cd ~/your_path/webots_hexapod
webots worlds/legacy_hexapod_ros2_bridge_test.wbt
```

Because the controller runs inside Webots and imports `rclpy`, launching Webots from a terminal that already sourced ROS 2 is important.

## ROS 2 topics

Published:

- `/joint_states`
- `/scan`
- `/imu/data_raw`
- `/camera/depth/image_raw`

Subscribed:

- `/cmd_vel`

## Quick test

In a second terminal:

```bash
source /opt/ros/humble/setup.bash
ros2 topic list
ros2 topic echo /scan
```

Command the hexapod with:

```bash
source /opt/ros/humble/setup.bash
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.08}, angular: {z: 0.0}}" -r 10
```

Turn in place with:

```bash
source /opt/ros/humble/setup.bash
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.0}, angular: {z: 0.4}}" -r 10
```

## Notes

- This is a first-pass bridge intended to get Webots sensors and gait control into ROS 2 quickly.
- The gait is still heuristic, not a finished terrain-aware locomotion controller.
- If Webots cannot import `rclpy`, make sure you launched it from a terminal where ROS 2 was sourced.
