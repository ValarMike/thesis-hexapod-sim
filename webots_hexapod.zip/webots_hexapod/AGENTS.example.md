# AGENTS.md

## Project

This repository contains a hexapod simulation project for Ubuntu 22.04 using:

- Webots
- ROS 2 Humble
- Python controllers

## Environment

Before running any ROS 2 command, source:

```bash
source /opt/ros/humble/setup.bash
```

If a local workspace exists, also source:

```bash
source ~/hexapod_ws/install/setup.bash
```

## Preferred commands

Use these commands when checking or running the project:

```bash
python3 --version
ros2 topic list
ros2 node list
ros2 pkg list | grep webots
webots --version
```

## Webots

The main ROS 2 bridge world is:

```text
worlds/legacy_hexapod_ros2_bridge_test.wbt
```

The ROS 2 bridge controller is:

```text
controllers/legacy_hexapod_ros2_bridge/legacy_hexapod_ros2_bridge.py
```

## ROS 2 topics

Expected published topics:

- `/joint_states`
- `/scan`
- `/imu/data_raw`
- `/camera/depth/image_raw`

Expected subscribed topic:

- `/cmd_vel`

## When editing

- Prefer `python3`
- Keep controller code simple and debuggable
- Do not change topic names unless necessary
- Prefer small, testable edits

## Validation

When possible, validate with:

```bash
ros2 topic list
ros2 topic echo /scan
ros2 topic echo /joint_states
```
